package ch4;

public class MiniCalcEx {

  public static void main(String[] args) {
    MiniCalc miniCalc = new MiniCalc();

    miniCalc.execute();
  }
}
