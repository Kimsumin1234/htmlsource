// main 메소드를 가진 클래스
// main 없는 클래스

public class App {

  public static void main(String[] args) throws Exception {
    System.out.println("Hello, World!");
  }
}
