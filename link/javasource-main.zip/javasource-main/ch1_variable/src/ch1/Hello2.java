package ch1;

public class Hello2 {
public static void main(String[] args) {
    // 변수 선언
    // 타입(자료형) 변수명 = 값;
    int var1 = 3;
    System.out.println("내가 좋아하는 숫자 "+var1);
}
}
