package ch4;

public class Data {

  int x;
}
