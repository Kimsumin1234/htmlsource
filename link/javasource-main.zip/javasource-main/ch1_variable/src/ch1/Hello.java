package ch1;

// 클래스 이름은 대문자로 시작(규칙) ★★★
// 클래스명은 한글 가능하나, 영어로 사용(규칙) ★★★
// System.out(sysout,아래화면에 출력),println(글자출력)
// shift + alt + 아래화살표 : 현제 코드 복사

public class Hello {
    public static void main(String[] args) {
        System.out.println("안녕하세요");
        System.out.println("안녕하세요");
        System.out.println("안녕하세요");
        System.out.println("안녕하세요");
    }
}
