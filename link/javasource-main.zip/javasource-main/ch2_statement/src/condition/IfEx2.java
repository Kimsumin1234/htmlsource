package condition;

public class IfEx2 {

  public static void main(String[] args) {
    // 점수가 90이상이면 A, 아니면 F
    int score = 90;

    if (score >= 90) {
      System.out.println("A");
    } else {
      System.out.println("F");
    }
  }
}
