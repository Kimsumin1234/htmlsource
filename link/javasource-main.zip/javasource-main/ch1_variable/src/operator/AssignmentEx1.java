package operator;

public class AssignmentEx1 {

  public static void main(String[] args) {
    int i = 3;
    i += 3; // i = i + 3; (왼쪽 오른쪽 둘다 i 일때만 사용)
    i /= 3; // i = i / 3;
    i *= 4; // i = i * 4;
    System.out.println(i);
  }
}
