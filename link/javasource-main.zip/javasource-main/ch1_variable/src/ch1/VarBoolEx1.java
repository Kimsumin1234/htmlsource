package ch1;

public class VarBoolEx1 {
    public static void main(String[] args) {
        // 3. 논리형 - boolean(1byte 할당) (true, false 값만 가짐)
        boolean flag = false;
        System.out.println("결과 : " + flag);
    }
}
